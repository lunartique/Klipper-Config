# my-klipper-configs
klipper config that i currently use

## i have a Sidewinder X1 with the following mods
- BL Touch by Waggster -> https://www.thingiverse.com/thing:3716043
- no z axis syn belt (i use Z TILT)
- filament runout sensor connected to X+
- magnatic aluminud bed with PEI sheet or FR4 sheet for TPU

i use fluidd as a gui

i use kiauth for software managemet/installation -> https://github.com/th33xitus/KIAUH

you will also need a cura plugin called "Mesh Print Size" 
it will tell klipper how big the base of the print is and probe the bed in that area.
